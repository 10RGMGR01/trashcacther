document.getElementById('start-game').addEventListener('click', () => {
    window.location.href = 'index.html';
});

document.getElementById('high-scores').addEventListener('click', () => {
    // TODO: Implement high scores functionality
    alert('High Scores coming soon!');
});

document.getElementById('instructions').addEventListener('click', () => {
    alert('Use arrow keys or A/D to move left and right.\nCatch the falling trash to score points!');
});