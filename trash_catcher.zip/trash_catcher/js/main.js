let gameActive = false;
let score = 0;
const player = document.getElementById('player');
const gameContainer = document.getElementById('game-container');
const scoreElement = document.getElementById('score-value');
const npcs = [
  document.getElementById('npc1'),
  document.getElementById('npc2'),
  document.getElementById('npc3'),
  document.getElementById('npc4'),
  document.getElementById('npc5')
];

// Add after the existing constants
const GROUND_LEVEL = window.innerHeight - 20; // 20px from bottom
const stackedTrash = new Map(); // Track stacked trash positions

// Add after the existing constants
let rainTimeout;
let rainDuration;
let rainInterval;
let activeRaindrops = new Set();

// Add after existing constants
const FLOOD_HEIGHT_PER_TRASH = 0.5; // pixels per trash item
let flood = null;

function createRaindrop() {
    // Create 3 raindrops at once for heavier rain effect
    for (let i = 0; i < 3; i++) {
        const raindrop = document.createElement('div');
        raindrop.className = 'raindrop';
        raindrop.style.left = `${Math.random() * 100}vw`;
        const duration = 0.3 + Math.random() * 0.3; // Faster falling speed
        raindrop.style.animationDuration = `${duration}s`;
        gameContainer.appendChild(raindrop);
        activeRaindrops.add(raindrop);

        // Remove the raindrop after animation
        setTimeout(() => {
            raindrop.remove();
            activeRaindrops.delete(raindrop);
        }, duration * 1000);
    }
}

function startRain() {
    // Clear any existing rain
    if (rainInterval) clearInterval(rainInterval);
    if (rainDuration) clearTimeout(rainDuration);
    activeRaindrops.clear();

    // Create raindrops more frequently (every 30ms instead of 50ms)
    rainInterval = setInterval(() => {
        if (!gameActive) {
            clearInterval(rainInterval);
            return;
        }
        createRaindrop();
    }, 30);

    // Stop rain after 20 seconds
    rainDuration = setTimeout(() => {
        clearInterval(rainInterval);
        activeRaindrops.forEach(raindrop => raindrop.remove());
        activeRaindrops.clear();
    }, 20000);
}

// NPC movement
const npcStates = npcs.map((npc, index) => ({
  position: (window.innerWidth / 6) * (index + 1), // Space NPCs evenly
  direction: Math.random() < 0.5 ? -1 : 1,
  speed: 2 + Math.random() * 2
}));

function moveNPCs() {
    npcs.forEach((npc, index) => {
        const state = npcStates[index];
        
        // Update position
        state.position += state.speed * state.direction;
        
        // Check boundaries and reverse direction
        if (state.position <= 0 || state.position >= window.innerWidth - 60) {
            state.direction *= -1;
            
            // Update visual direction
            if (state.direction > 0) {
                npc.classList.remove('flip'); // Walking right (default)
            } else {
                npc.classList.add('flip'); // Walking left
            }
        }
        
        // Apply new position
        npc.style.left = `${state.position}px`;
    });
}

// Initialize NPCs with correct starting direction
npcs.forEach((npc, index) => {
    if (npcStates[index].direction < 0) {
        npc.classList.add('flip');
    }
});

// Player movement
let playerX = window.innerWidth / 2;
const playerSpeed = 8;
const keys = {};

document.addEventListener('keydown', (e) => {
  keys[e.key] = true;
});

document.addEventListener('keyup', (e) => {
  keys[e.key] = false;
});

// Touch controls
let touchStartX = 0;
gameContainer.addEventListener('touchstart', (e) => {
  touchStartX = e.touches[0].clientX;
});

gameContainer.addEventListener('touchmove', (e) => {
  e.preventDefault();
  const touchX = e.touches[0].clientX;
  const diff = touchX - touchStartX;
  playerX += diff;
  touchStartX = touchX;
  updatePlayerPosition();
});

function updatePlayerPosition() {
    playerX = Math.max(40, Math.min(window.innerWidth - 40, playerX));
    const groundLevel = getGroundLevelAtPosition(playerX);
    player.style.left = `${playerX}px`;
    player.style.bottom = `${window.innerHeight - groundLevel}px`;
}

function movePlayer() {
  if (keys['ArrowLeft'] || keys['a']) {
    playerX -= playerSpeed;
  }
  if (keys['ArrowRight'] || keys['d']) {
    playerX += playerSpeed;
  }
  updatePlayerPosition();
}

// Add after the player movement constants
function getGroundLevelAtPosition(x) {
    const column = Math.floor(x / 30) * 30;
    const stackHeight = stackedTrash.get(column) || 0;
    return GROUND_LEVEL - stackHeight;
}

// Trash generation and falling
function createTrash() {
  const npcIndex = Math.floor(Math.random() * npcs.length);
  const npc = npcs[npcIndex];
  const npcRect = npc.getBoundingClientRect();
  
  const trash = document.createElement('div');
  trash.className = 'trash';
  trash.style.left = `${npcRect.left + npcRect.width / 2 - 15}px`;
  trash.style.top = `${npcRect.bottom}px`;
  gameContainer.appendChild(trash);

  const fallSpeed = 3 + Math.random() * 2;
  
  // Replace the existing fall function inside createTrash
  function fall() {
    const top = parseFloat(trash.style.top);
    const left = parseFloat(trash.style.left);
    
    // Check for collision with player
    const trashRect = trash.getBoundingClientRect();
    const playerRect = player.getBoundingClientRect();
    
    // Replace the collision check in the fall function
    if (
        trashRect.bottom >= playerRect.top &&
        trashRect.top <= playerRect.bottom &&
        trashRect.right >= playerRect.left &&
        trashRect.left <= playerRect.right &&
        trashRect.top < playerRect.bottom - 20 // Only collect if hitting the player from above
    ) {
        score++;
        scoreElement.textContent = score;
        trash.remove();
        return;
    }

    // Check for ground or stack collision
    const column = Math.floor(left / 30) * 30; // Align to 30px grid
    const stackHeight = stackedTrash.get(column) || 0;
    const stackTop = GROUND_LEVEL - stackHeight;

    if (top >= stackTop) {
        // Stack the trash
        trash.style.top = `${stackTop}px`;
        stackedTrash.set(column, stackHeight + 20); // Add height of new trash

        // Update flood height based on total trash
        const totalTrash = Array.from(stackedTrash.values()).reduce((sum, height) => sum + height, 0);
        const floodHeight = Math.min(totalTrash * FLOOD_HEIGHT_PER_TRASH, window.innerHeight * 0.7);
        flood.style.height = `${floodHeight}px`;

        // Check if stack reaches NPCs
        if (GROUND_LEVEL - stackHeight <= 150) { // 150px from top of bridge
            gameOver();
            return;
        }
        return;
    }

    trash.style.top = `${top + fallSpeed}px`;
    requestAnimationFrame(fall);
  }

  fall();
}

// Game loop
function gameLoop() {
  if (!gameActive) return;
  movePlayer();
  moveNPCs();
  requestAnimationFrame(gameLoop);
}

// Replace the game start section
function startGame() {
    gameActive = true;
    score = 0;
    scoreElement.textContent = score;
    stackedTrash.clear();
    
    // Remove all existing trash elements
    document.querySelectorAll('.trash').forEach(trash => trash.remove());
    
    player.style.bottom = '20px';
    
    // Clear any existing timeouts
    if (rainTimeout) clearTimeout(rainTimeout);
    if (rainDuration) clearTimeout(rainDuration);
    activeRaindrops.forEach(raindrop => raindrop.remove());
    activeRaindrops.clear();
    
    // Create flood element if it doesn't exist
    if (!flood) {
        flood = document.createElement('div');
        flood.className = 'flood';
        gameContainer.appendChild(flood);
    }
    flood.style.height = '0px';
    
    // Schedule rain to start after 30 seconds
    rainTimeout = setTimeout(startRain, 20000);
    
    gameLoop();
    trashInterval = setInterval(createTrash, 1000);
}

// Add game over function
function gameOver() {
    gameActive = false;
    clearInterval(trashInterval);
    
    // Clear rain effects
    clearTimeout(rainTimeout);
    clearTimeout(rainDuration);
    clearInterval(rainInterval);
    activeRaindrops.forEach(raindrop => raindrop.remove());
    activeRaindrops.clear();
    
    if (flood) {
        flood.style.height = '0px';
    }
    
    const playAgain = confirm(`Game Over! Your score: ${score}\nPlay again?`);
    if (playAgain) {
        startGame();
    } else {
        window.location.href = 'menu.html';
    }
}

// Start the game when the page loads
window.addEventListener('load', startGame);

// Handle window resize
window.addEventListener('resize', () => {
  playerX = Math.min(playerX, window.innerWidth - 40);
  updatePlayerPosition();
  
  // Reset NPC positions on resize
  npcStates.forEach((state, index) => {
    state.position = Math.min(state.position, window.innerWidth - 60);
    npcs[index].style.left = `${state.position}px`;
  });
});